/**
******************************************************************************
* @file     main.c
* @author   AE team
* @version  V1.1.0
* @date     09/09/2019
* @brief
******************************************************************************
* @copy
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* <h2><center>&copy; COPYRIGHT 2019 MindMotion</center></h2>
*/
#include "string.h"
#include "HAL_device.h"
#include "stdio.h"
#include "stdbool.h"
#include "HAL_conf.h"

//The size of each EEPROM page
#define PAGESIZE 16
//Device address of EEPROM
#define EEPROM_ADDR 0xA0
#define MAX(a,b)((a)>(b)?(a):(b))
#define MIN(a,b)((a)<(b)?(a):(b))
typedef struct
{
    //Flag of whether I2C is transmitting
    u8 busy;
    u8 ack;
    //Flag of whether I2C is right
    u8 fault;
    //Flag of I2C transmission direction
    u8 opt;
    //sub address
    u8 sub;
    //number
    u8 cnt;
    //buffer
    u8 *ptr;
    //used to determine if sub addresses need to be sent in interrupt
    u8 sadd;
} i2c_def;
i2c_def i2c;
enum {WR, RD};

char printBuf[100];
void Uart_ConfigInit(u32 bound);
void UartSendGroup(u8* buf, u16 len);
void UartSendAscii(char *str);
void I2CWrite(u8 sub, u8* ptr, u16 len);
void I2CRead(u8 sub, u8* ptr, u16 len);
void I2C_MasterMode_Init(I2C_TypeDef *I2Cx, u32 uiI2C_speed);
void I2CSetDeviceAddr(I2C_TypeDef *I2Cx, u8 deviceaddr);
void I2C_WaitEEready(void);
void I2C_TXByte(u8 dat);
u8 I2C_SendBytes(u8 sub, u8* ptr, u16 cnt);
u8 I2C_SendPacket(u8 sub, u8* ptr, u16 cnt);
void I2C_RevBytes(void);
void I2C_RcvPacket(u8 sub, u8* ptr, u16 cnt);
void I2C_Check(void);
void I2CInit(void);

u8 buffer0[128] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99};
u8 buffer1[128];

/*******************************************************************************
* @name   : InitSystick
* @brief  : Init Systick
* @param  : None
* @retval : void
*******************************************************************************/
void InitSystick()
{
    SysTick_Config(SystemCoreClock / 1000);
    NVIC_SetPriority(SysTick_IRQn, 0x00);
}

/*******************************************************************************
* @name   : SysTick_Handler
* @brief  : Systick interrupt
* @param  : None
* @retval : void
*******************************************************************************/
void SysTick_Handler()
{
    static u32 cnt;
    cnt++;
}

/*******************************************************************************
* @name   : main
* @brief  : I2C poll mode read and write EEPROM
* @param  : None
* @retval : void
*******************************************************************************/
int main(void)
{

    SystemInit();
    InitSystick();

    I2CInit();

    //Write 15 bytes from buffer0[128] to 0x03 of EEPROM
    I2CWrite(0x10, buffer0, 0x10);
    //Read 10 bytes from 0x05 of EEPROM to buffer1[128]
    I2CRead(0x10, buffer1, 0x10);

    while(1)
    {
    }
}


/*******************************************************************************
* @name      : I2CWrite
* @brief     : Write a data packet
* @param sub : Sub address of EEPROM
* @param ptr : Data in the buffer
* @param len : Number of data
* @retval    : void
*******************************************************************************/
void I2CWrite(u8 sub, u8* ptr, u16 len)
{
    do
    {
        //write data
        I2C_SendPacket(sub, ptr, len);
        //till I2C is not work
        while(i2c.busy);
    }
    while(!i2c.ack);
}

/*******************************************************************************
* @name      : I2CRead
* @brief     : Receive a data packet
* @param sub : Sub address of EEPROM
* @param ptr : Buffer to storage data
* @param len : Number of data
* @retval    : void
*******************************************************************************/
void I2CRead(u8 sub, u8* ptr, u16 len)
{
    do
    {
        //read data
        I2C_RcvPacket(sub, ptr, len);
        //till I2C is not work
        while(i2c.busy);
    }
    while(!i2c.ack);
}

/*******************************************************************************
* @name              : Initializes the I2Cx master mode
* @brief             : Initializes I2C
* @param I2Cx        : where x can be 1 or 2 to select the I2C peripheral.
* @param uiI2C_speed : I2C speed
* @retval            : void
*******************************************************************************/
void I2C_MasterMode_Init(I2C_TypeDef *I2Cx, u32 uiI2C_speed)
{
    I2C_InitTypeDef I2C_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_1);

    //I2C uses PB8, PB9
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Need extra pull
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    //Configure I2C as master mode
    I2C_InitStructure.I2C_Mode = I2C_Mode_MASTER;
    I2C_InitStructure.I2C_OwnAddress = 0;
    I2C_InitStructure.I2C_Speed = I2C_Speed_STANDARD;
    I2C_InitStructure.I2C_ClockSpeed = uiI2C_speed;

    I2C_Init(I2Cx, &I2C_InitStructure);
    I2C_Cmd(I2Cx, ENABLE);

}

/*******************************************************************************
* @name             : I2CSetDeviceAddr
* @brief            : Set the device address
* @param I2Cx       : where x can be 1 or 2 to select the I2C peripheral.
* @param deviceaddr : device address
* @retval           : void
*******************************************************************************/
void I2CSetDeviceAddr(I2C_TypeDef *I2Cx, u8 deviceaddr)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    //I2C uses PB8, PB9
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8 | GPIO_Pin_9;

    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    I2C_Cmd(I2Cx, DISABLE);
    //Set the device address
    I2C_Send7bitAddress(I2Cx, deviceaddr, I2C_Direction_Transmitter);
    I2C_Cmd(I2Cx, ENABLE);

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Need extra pull
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/*******************************************************************************
* @name      : I2C_WaitEEready
* @brief     : Wait for EEPROM getting ready.
* @param dat : None
* @retval    : void
*******************************************************************************/
void I2C_WaitEEready(void)
{
    //eeprom operation interval delay
    u32 i = 10000;
    while(i--);
}

/*******************************************************************************
* @name      : I2C_TXByte
* @brief     : Send a byte
* @param dat : data
* @retval    : void
*******************************************************************************/
void I2C_TXByte(u8 dat)
{
    I2C_SendData(I2C1, dat);
    //Checks whether transmit FIFO completely empty or not
    while(I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFE) == 0);
}

/*******************************************************************************
* @name      : I2C_RevBytes
* @brief     : Receive a byte
* @param ptr : None
* @retval    : void
*******************************************************************************/
void I2C_RevBytes(void)
{
    u8 i, flag = 0, _cnt = 0;
    for (i = 0; i < i2c.cnt; i++)
    {
        while(1)
        {
            //Write command is sent when RX FIFO is not full
            if ((I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFNF)) && (flag == 0))
            {
                //Configure to read
                I2C_ReadCmd(I2C1);
                _cnt++;
                //When flag is set, receive complete
                if (_cnt == i2c.cnt)
                    flag = 1;
            }
            //Check receive FIFO not empty
            if (I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_RFNE))
            {
                //read data to i2c.ptr
                i2c.ptr[i] = I2C_ReceiveData(I2C1);
                break;
            }
        }
    }
}

/*******************************************************************************
* @name      : I2C_SendBytes
* @brief     : Send bytes
* @param sub : Sub address of EEPROM
* @param ptr : Data in the buffer
* @param cnt : Number of data
* @retval    : The state of this transmission
*******************************************************************************/
u8 I2C_SendBytes(u8 sub, u8* ptr, u16 cnt)
{
    //Send sub address
    I2C_TXByte(sub);
    while (cnt --)
    {
        I2C_TXByte(*ptr);
        //Point to the next data
        ptr++;
    }
    //Stop transmission
    I2C_GenerateSTOP(I2C1, ENABLE);
    //Checks whether stop condition has occurred or not.
    while((I2C_GetITStatus(I2C1, I2C_IT_STOP_DET)) == 0);
    i2c.ack = true;
    //I2C operation stops
    i2c.busy = false;
    //Wait for EEPROM getting ready.
    I2C_WaitEEready();
    return true;
}

/*******************************************************************************
* @name      : I2C_SendPacket
* @brief     : Send a data packet
* @param sub : Sub address of EEPROM
* @param ptr : Data in the buffer
* @param cnt : Number of data
* @retval    : The state of this transmission
*******************************************************************************/
u8 I2C_SendPacket(u8 sub, u8* ptr, u16 cnt)
{
    u8 i;
    //i2c option flag set to write
    i2c.opt = WR;
    //number to send
    i2c.cnt = cnt;
    //sub address
    i2c.sub = sub;
    //I2C operation starts
    i2c.busy = true;
    i2c.ack = false;

    if ((sub % PAGESIZE) > 0)
    {
        //Need temp number of data, just right to the page address
        u8 temp = MIN((PAGESIZE - sub % PAGESIZE), i2c.cnt);
        //If WRITE successful
        if(I2C_SendBytes(sub, ptr, temp))
        {
            ptr +=  temp;
            i2c.cnt -=  temp;
            sub += temp;
        }
        //i2c.cnt = 0 means transmition complete
        if (i2c.cnt == 0) return true;
    }
    for (i = 0; i < (i2c.cnt / PAGESIZE); i++)
    {
        //Full page write
        if (I2C_SendBytes(sub, ptr, PAGESIZE))
        {
            //Point to the next page
            ptr += PAGESIZE;
            sub += PAGESIZE;
            i2c.cnt -= PAGESIZE;
        }
        if (i2c.cnt == 0) return true;
    }
    if (i2c.cnt > 0)
    {
        if (I2C_SendBytes(sub, ptr, i2c.cnt)) return true;
    }
    //I2C operation ends
    i2c.busy = false;
    i2c.ack = true;
    return false;
}

/*******************************************************************************
* @name      : I2C_RcvPacket
* @brief     : Receive a data packet
* @param sub : Sub address of EEPROM
* @param ptr : Buffer to storage data
* @param cnt : Number of data
* @retval    : void
*******************************************************************************/
void I2C_RcvPacket(u8 sub, u8* ptr, u16 cnt)
{
    //I2C operation starts
    i2c.busy = true;
    i2c.ack = false;
    i2c.sub = sub;
    i2c.ptr = ptr;
    i2c.cnt = cnt;

    //Send sub address
    I2C_TXByte(i2c.sub);
    I2C_RevBytes();
    I2C_GenerateSTOP(I2C1, ENABLE);
    //Checks whether stop condition has occurred or not.
    while((I2C_GetITStatus(I2C1, I2C_IT_STOP_DET)) == 0);

    i2c.busy = false;
    i2c.ack = true;
    I2C_WaitEEready();
}

/*******************************************************************************
* @name   : I2CInit
* @brief  : Initial I2C
* @param  : None
* @retval : void
*******************************************************************************/
void I2CInit()
{
    //Initial value of i2c struct
    memset(&i2c, 0x00, sizeof(i2c));
    //Initializes the I2C master mode
    I2C_MasterMode_Init(I2C1, 100000);
    //Set the EEPROM address
    I2CSetDeviceAddr(I2C1, EEPROM_ADDR);
}

/*******************************************************************************
* @name   : Uart_ConfigInit
* @brief  : Uart Config Init
* @param  : u32 bound
* @retval : void
*******************************************************************************/
void Uart_ConfigInit(u32 bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    UART_InitStructure.UART_BaudRate = bound;
    UART_InitStructure.UART_WordLength = UART_WordLength_8b;
    UART_InitStructure.UART_StopBits = UART_StopBits_1;
    UART_InitStructure.UART_Parity = UART_Parity_No;
    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    //Multiplexing push-pull output
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    //Floating input
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}
/*******************************************************************************
* @name   : UartSendByte
* @brief  : Uart Send Byte
* @param  : u8 dat
* @retval : void
*******************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

/*******************************************************************************
* @name   : UartSendGroup
* @brief  : Uart Send Group
* @param  : u8* buf,u16 len
* @retval : void
*******************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

/*******************************************************************************
* @name   : UartSendAscii
* @brief  : Uart Send Ascii
* @param  : char *str
* @retval : void
*******************************************************************************/
void UartSendAscii(char *str)
{
    while(*str)
        UartSendByte(*str++);
}



/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/*-------------------------(C) COPYRIGHT 2019 MindMotion ----------------------*/

